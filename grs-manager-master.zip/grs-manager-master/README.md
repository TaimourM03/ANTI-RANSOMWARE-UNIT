# GRS Manager

El GRS Manager es un programa de terminal para la gestión del [servidor GRS](https://github.com/cgonzalezc21/grs-docker). En especifico, tiene las siguientes tres funcionalidades generales:

1. Creación de reportes basados en la información de la BBDD.
2. Gestión de base de datos
3. Herramienta para la detección y clasificación de ransomware

# Implementación

El gestor del GRS está pensado para implementarse en muy pocos pasos y de manera rápida y sencilla. 

1. Instala los paquetes necesarios para la implementación

```
sudo apt install pip python3 git
```

2. Clona este repositorio

```
git clone https://github.com/cgonzalezc21/grs-manager.git
```

3. Entra al directorio del repositorio e instala las dependencias

```
cd grs-manager
pip install -r requirements.txt
```

4. Configura las variables del manager en `./modulos/vars.json`

5. Ejecuta `main.py`

```
python3 main.py
```
