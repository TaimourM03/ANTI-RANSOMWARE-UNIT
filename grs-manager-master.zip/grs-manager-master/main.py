from random import randint
import pymongo
from tabulate import tabulate
from terminaltables import AsciiTable
from os import system
from time import sleep

from modulos.completer import *
from modulos.ransomdb_admin import *
from modulos.reports import *
from modulos.ransom_hash import *

from colorama import init
init(strip=not sys.stdout.isatty())
from termcolor import cprint
from pyfiglet import figlet_format





def clear():
    system("clear")
    menu()
def menu():
    fonts = ["ivrit", "mini", "script", "shadow", "slant", "small",
            "standard"]
    colors = ["red", "blue", "white", "yellow"]
    n = randint(0, len(fonts)-1)
    cn = randint(0, len(colors)-1)
    cprint(figlet_format('Ransom-report', font=fonts[n]), colors[cn])

def ayuda():
    print()
    print("     reports     Módulo para generar reportes\n")
    print("     hashes      Módulo para trabajar con muestras de ransomware\n")
    print("     bbdd        Lanza el administrador de la base de datos\n")
    print("     update      Actualiza ransom-report\n")
    print("     help        Muestra este menu\n")
    print("     clear       Limpia la terminar\n")
    print("     exit        Salir de la aplicacion\n")

def main():
    system("clear")
    menu()
    cmd = ""
    while cmd != "exit":
        cmd = input("garu@ransom-report > ")
        if cmd == "help" or cmd == "?":
            ayuda()
        elif cmd == "clear":
            clear()
        elif cmd == "bbdd":
            garu_bd_admin()
        elif cmd == "reports":
            reports()
        elif cmd == "update":
            system('cd ~/ransom-report-client && git pull')
            sleep(2)
            cmd = "exit"
            system('ransom-report')
            clear()
        elif cmd == "":
            pass
        elif cmd == "hashes":
            hashes()
        elif cmd == "exit":
            system('clear')
        else:
            print("Orden no encontrada. Utilice 'help' o '?' para más informacion")
main()
