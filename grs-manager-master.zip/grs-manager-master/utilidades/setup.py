from os import system

system('cd ~ && sudo apt-get -y install libfuzzy-dev pip git')
system("git clone https://github.com/CarlosSohn/ransom-report-client.git")
requirements = ["pymongo", "plotext", "prompt_toolkit", "terminaltables", "colorama", "termcolor", "pyfiglet", "tqdm", "requests", "hashlib", "fpdf", "tabulate", "pyimpfuzzy"]

for i in requirements:
    system("pip install %s"%i)
ruta = "python3 ~/ransom-report-client/main.py"

system('echo \'alias ransom-report=\"cd ~/ransom-report-client/ && python3 main.py\"\' >> ~/.bashrc')
system('echo \'alias ransom-report=\"cd ~/ransom-report-client/ && python3 main.py\"\' >> ~/.zshrc')


system('reboot')
#system('source ~/.zshrc')
#system('source ~/.bashrc')
