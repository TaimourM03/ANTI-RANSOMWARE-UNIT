import os
from os import system

for i in os.listdir():
    if ".py" in i:
        pass
    else:
        system("7z e -pinfected %s"%i)
        os.remove(i)

