from random import randint
from getpass import getpass
from os import system
import os
import pymongo
from terminaltables import AsciiTable

from time import sleep

from modulos.completer import complete

import sys
from colorama import init
init(strip=not sys.stdout.isatty())
from termcolor import cprint
from pyfiglet import figlet_format
import json

# Variables #################################################################
vars_file = open("vars.json")
env = json.load(vars_file)

mongo_ip = env["mongo_ip"]
mongo_port = env["mongo_port"]
mongo_db = env["mongo_db"]
mongo_collection = env["mongo_collection"]
mongo_user = env["mongo_user"]
mongo_password = env["mongo_password"]

#cliente = pymongo.MongoClient("mongodb://garu:garu@10.100.10.90:27017/ransom")
#ransom_db = cliente["ransom"]
#bandas = ransom_db["bandas"]
cliente = pymongo.MongoClient("mongodb://%s:%s@%s:%s"%(mongo_user, mongo_password, mongo_ip, mongo_port))
ransom_db = cliente[mongo_db]
bandas = ransom_db[mongo_collection]

#############################################################################
def menu():
    fonts = ["ivrit", "mini", "script", "shadow", "slant", "small",
            "standard"]
    colors = ["red", "blue", "white", "yellow"]
    n = randint(0, len(fonts)-1)
    cn = randint(0, len(colors)-1)
    cprint(figlet_format('Ransom DB', font=fonts[n]), colors[cn])

def clear():
    system("clear")

def clearm():
    system("clear")
    menu()

def add_reg():
    cmd = ""
    nom = "-"
    while cmd != "exit":
        cmd = input("garu@ransombd[crear] > ")
        if cmd == "help" or cmd == "?":
            print("Comandos disponibles\n")
            print("     Antes de comenzara a añadir registros debes dar un nombre al documento con 'name'\n")
            print("     name [NOMBRE]   Define el nombre del nuevo documento\n")
            print("     clear           Limpiar la terminal\n")
            print("     exit            Salir sin guadar\n")
        elif cmd == "clear":
            clear()
        elif "name " in cmd:
            nom = cmd.replace("name ", "")
            regs = []
            emps = []
            fechas = []
            paises = []
            continentes = []
            while cmd != "exit":
                cmd = input("garu@ransombd[crear][%s] > "%nom)
                if cmd == "help" or cmd == "?":
                    print("Comandos disponibles\n")
                    print("     reg+ [empresa]:[fecha]  Añade un nuevo registro\n")
                    print("     help, ?                 Muestra este menu de ayuda\n")
                    print("     clear                   Limpia la terminal\n")
                    print("     temp                    Mostrar registros sin guardar\n")
                    print("     commit                  Guarda los cambios\n")
                    print("     exit                    Termina la edicion de %s\n"%nom)
                elif "reg+ " in cmd:
                    rtemp = cmd.replace("reg+ ", "").replace(": ", ":").split(":")
                    if len(rtemp) != 2:
                        print("\nLos dos campos separados por ':' son obligatorios\n")
                    else:
                        print()
                        pais_cont = complete("paises")
                        
                        regs.append([rtemp[0], rtemp[1], pais_cont[0], pais_cont[1]])
                        
                        emps.append(rtemp[0])
                        fechas.append(rtemp[1])
                        paises.append(pais_cont[0])
                        continentes.append(pais_cont[1])
                        
                        print("\n[+] Hecho\nLa base de datos no se sobrescribirá hasta que ejecutes el comando 'commit'\n")
                elif cmd == "temp":
                    for i in range(len(regs)):
                        print(i, regs[i])
                elif cmd == "clear":
                    clear()
                elif cmd == "commit":
                    try:
                        bandas.insert_one({"Nombre" : nom, "Empresas" : emps, "Fechas" : fechas, "Paises" : paises, "Continentes" : continentes})
                    except:
                        print("[*] Error 1")
                    else:
                        print("[+] Hecho")
                        sleep(0.5)
                        cmd = "exit"
                elif cmd == "exit":
                    pass
                elif cmd == "":
                    pass
        elif cmd == "":
            pass
        elif cmd == "exit":
            pass

def show_tab(nom):
    x = bandas.find_one({"Nombre" : nom})
    t = [["ID", "Empresas", "Fecha de ataque", "Pais", "Continente"]]
    nom = x["Nombre"]
    emp = x["Empresas"]
    fec = x["Fechas"]
    pai = x["Paises"]
    con = x["Continentes"]
    for i in range(len(emp)):
        t.append([i, emp[i], fec[i], pai[i], con[i]])
    table = AsciiTable(t)
    print(table.table)

def crea_reg(nom):
    emp = input("Empresa: ")
    fecha = input("Fecha de ataque [dd-mm-aaaa]: ")
    pais_cont = complete("paises")
    pais = pais_cont[0]
    continente = pais_cont[1]
    t = [["Empresa", "Fecha de ataque", "Pais", "Continente"], [emp, fecha, pais, continente]]
    tm = AsciiTable(t)
    print("Se añadirá la siguiente información a %s"%nom)
    print(tm.table)
    fin = input("Presiona enter para añadir o escribe 'c' para cancelar")
    if fin == "":
        return [emp, fecha, pais, continente]
    else:
        return []

def mod():
    cmd = ""
    nom = ""
    nom = complete("bandas")
    x = bandas.find_one({"Nombre" : nom})
    emp = x["Empresas"]
    fec = x["Fechas"]
    pai = x["Paises"]
    con = x["Continentes"]
    
    while cmd != "exit":
        cmd = input("garu@ransombd[update][%s] > "%nom)
        regs = []
        emps = []
        fechas = []
        paises = []
        continentes = []

        
        if cmd == "help" or cmd == "?":
            print()
            print("     shall                   Muestra todos los registros de %s\n"%nom)
            print("     reg+ [empresa]:[fecha]  Añade un nuevo registro\n")
            print("     mod [ID]                Permite modificar un registro por su ID\n")
            print("     del [ID]                Permite eliminar un registro por su ID\n")
            print("     temp                    Muestra los cambios sin guardar\n")
            print("     commit                  Guarda los cambios y termina\n")
            print("     clear                   Limpia la terminal\n")
            print("     help, ?                 Muestra este mensaje de ayuda\n")
            print("     exit                    Sale sin guardar los cambios\n")
        elif cmd == "shall":
            show_tab(nom)
        elif "reg+ " in cmd:
            rtemp = cmd.replace("reg+ ", "").replace(": ", ":").split(":")
            if len(rtemp) != 2:
                print("\nLos dos campos separados por ':' son obligatorios\n")
            else:
                print()
                pais_cont = complete("paises")
                
                regs.append([rtemp[0], rtemp[1], pais_cont[0], pais_cont[1]])
                emps.append(rtemp[0])
                fechas.append(rtemp[1])
                paises.append(pais_cont[0])
                continentes.append(pais_cont[1])
                
                emp.append(rtemp[0])
                fec.append(rtemp[1])
                pai.append(pais_cont[0])
                con.append(pais_cont[1])
        elif "mod " in cmd:
            rtemp = cmd.split(" ")
            if len(rtemp) != 2:
                print("[*] Sintaxis incorrecta. Use 'help' o '?' para más información.")
            elif int(rtemp[1]) <= len(emp):
                i = int(rtemp[1])
                #reg_act = [rtemp[1], emp[i], fec[i], pai[i], con[i]]
                while cmd != "abort":
                    cmd = input("garu@ransombd[update][%s][reg:%s] > "%(nom, rtemp[1]))
                    if cmd == "help" or cmd == "?":
                        print()
                        print("     show            Ver los valores actuales\n")
                        print("     nom [empresa]   Permite cambiar el nombre de la empresa\n")
                        print("     data [fecha]    Permite cambiar la fecha del ataque\n")
                        print("     pais            Permite cambiar el pais de la empresa\n")
                        print("     commit          Guarda los cambios en la ransombd\n")
                        print("     abort           Finaliza la edicion de este registro sin guardar los cambios\n")
                        print("     clear           Limpia la terminal\n")
                        print("     help, ?         Muestra este mensaje de ayuda\n")
                    elif cmd == "show":
                        reg_act = [rtemp[1], emp[i], fec[i], pai[i], con[i]]
                        tr = [["ID", "Empresa", "Fecha de ataque", "Pais", "Continente"], reg_act]
                        trs = AsciiTable(tr)
                        print(trs.table)
                    elif "nom " in cmd:
                        n = cmd.replace("nom ", "")
                        emp[i] = n
                        print("[+] Hecho")
                    elif "data " in cmd:
                        n = cmd.split(" ")
                        if len(n) == 2:
                            fec[i] = n[1]
                            print("[+] Hecho")
                        else:
                            print("[*] Sintaxis incorrecta. Use 'help' o '?' para más información.")
                    elif cmd == "pais":
                        n = complete("paises")
                        pai[i] = n[0]
                        con[i] = n[1]
                        print("[+] Hecho")
                    elif cmd == "clear":
                        clear()
                    elif cmd == "abort":
                        pass
                    elif cmd == "commit":
                        # ||
                        b = {"Nombre" : nom}
                        datos_n = {"$set" : {"Empresas": emp, "Fechas" : fec, "Paises" : pai, "Continentes" : con}}
                        bandas.update_one(b, datos_n)
                        cmd = "abort"
                    elif cmd == "":
                        pass
                    else:
                        print("Comando desconocido. Use 'help' o '?' para más información")
            else:
                if len(emp) == 1:
                    print("ID no identificado. El rango actual es 0")
                else:
                    print("ID no identificado. El rango actual oscila entre 0 y %s"%len(emp)-1)
            pass
        elif "del " in cmd:
            reg_d = cmd.split(" ")
            if len(reg_d) == 2:
                print()
                conf_del = input("[!] Para confirmar, escribe nuevamente el ID: ")
                print()
                if conf_del == reg_d[1]:
                    i = int(reg_d[1])
                    emp.remove(emp[i])
                    fec.remove(fec[i])
                    pai.remove(pai[i])
                    con.remove(con[i])
                    b = {"Nombre" : nom}
                    datos_n = {"$set" : {"Empresas": emp, "Fechas" : fec, "Paises" : pai, "Continentes" : con}}
                    bandas.update_one(b, datos_n)
                    print("[-] Registro eliminado\n")
                else:
                    print("[!] Operación abortada\n")
            else:
                print("[!] Sintaxis incorrecta")
        elif cmd == "temp":
            pass
        elif cmd == "commit":
            b = {"Nombre" : nom}
            datos_n = {"$set" : {"Empresas": emp, "Fechas" : fec, "Paises" : pai, "Continentes" : con}}
            bandas.update_one(b, datos_n)
            
        elif cmd == "clear":
            clear()
        elif cmd == "exit":
            pass

def ayuda():
    print("Comandos disponibles para la base de datos\n")
    print("     crear           Crea un nuevo documento en la base de datos\n")
    print("     update          Modifica la información del registro manualmente\n")
    print("     borrar          Elimina uno o varios documentos de la base de datos\n")
    print("     push            Ejecuta un modulo localmente y sube la información a la base de datos\n")
    print("     clear           Limpia la terminal\n")
    print("     help, ?         Muestra este menu de ayuda\n")
    print("     exit            Sale de este módulo\n")



def garu_bd_admin():
    
    clearm()
    cmd = "" 
    while cmd != "exit":
        cmd = input("garu@ransombd > ")
        if cmd == "crear":
            add_reg()
        elif cmd == "update":
            mod()
        elif cmd == "borrar":
            print("Modulo en proceso")
        elif cmd == "exit":
            pass
        elif cmd == "":
            pass
        elif cmd == "help" or cmd == "?":
            ayuda()
        elif cmd == "clear":
            clear()
        else:
            print("Comando no reconocido. Usa 'help' o '?' para consultar los comandos disponibles.")

