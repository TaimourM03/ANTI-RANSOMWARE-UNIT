import plotext as plt
from os import system
from modulos.completer import *
import pymongo
import json
import json

# Variables #################################################################
vars_file = open("vars.json")
env = json.load(vars_file)

mongo_ip = env["mongo_ip"]
mongo_port = env["mongo_port"]
mongo_db = env["mongo_db"]
mongo_collection = env["mongo_collection"]
mongo_user = env["mongo_user"]
mongo_password = env["mongo_password"]

cliente = pymongo.MongoClient("mongodb://%s:%s@%s:%s"%(mongo_user, mongo_password, mongo_ip, mongo_port))
ransom_db = cliente[mongo_db]
bandas = ransom_db[mongo_collection]
tot = bandas.find()
###########################################################################

def temp0():
    c = 0
    nums = []
    ps = []
    paises = {}
    for i in tot:
        for b in i["Paises"]:
            if b in paises:
                paises[b] += 1
            else:
                paises[b] = 1
    for i in paises:
        nums.append(paises[i])
        ps.append(i+" [%s]"%str(paises[i]))
    plt.bar(ps, nums, orientation = "h", width = 0.3, marker = 'fhd')
    plt.title("TOTAL DE ATAQUES POR PAISES")
    plt.theme("clear")
    plt.show()

def temp1():
    resultado = {}
    pais = complete("paises")
    nums = []
    bands = []
    empresas  =[]

    for i in tot:
        for p in range(len(i["Paises"])):
            if pais[0] == i["Paises"][p]:
                if i["Nombre"] in resultado:
                    resultado[i["Nombre"]] += 1
                else:
                    resultado[i["Nombre"]] = 1
                empresas.append([i["Nombre"], i["Empresas"][p], i["Fechas"][p]])


    for i in resultado:
        bands.append(i+" [%s]"%str(resultado[i]))
        nums.append(resultado[i])

    plt.bar(bands, nums, orientation = "h", width = 0.5, marker = 'fhd')
    plt.title("TOTAL DE ATAQUES EN %s"%pais[0].upper())
    plt.theme("clear")
    plt.show()
    #print(empresas, len(empresas))



def temp2():
    plt.date_form('d-m-Y')
    mes = {"01" : "Ene", "02" : "Feb", "03" : "Mar",
            "04" : "Abr", "05" : "May", "06" : "Jun",
            "07" : "Jul", "08" : "Ago", "09" : "Sep",
            "10" : "Oct", "11" : "Nov", "12" : "Dic"}
    band = complete("bandas")
    fechas = []
    for i in tot:
        if i["Nombre"] == band:
            fechas = i["Fechas"]
    fecs = []
    for i in fechas:
        fecs.append(plt.string_to_datetime(i))
    fechas = plt.datetimes_to_string(sorted(fecs))
    dates = {}
    labels = []
    for i in fechas:
        x = i.split("-")[1]
        y = i.split("-")[2]
        z = x+"-"+y
        mes_a = mes[x]+" "+y
        if mes_a in dates:
            dates[mes_a] += 1
        else:
            dates[mes_a] = 1
            labels.append(mes[x])
    fechas = []
    datos = []
    for i in dates:
        fechas.append(i)
        datos.append(dates[i])
    #plt.bar(fechas, datos, orientation = "h", width = 0.5, marker = 'fhd')
    plt.plot(datos, marker = 'fhd')
    xticks = [i+1 for i in range(len(datos))]
    #xlabels = [fechas[i] for i in range(len(datos))]
    xlabels = [labels[i]+" [%s]"%datos[i] for i in range(len(datos))]
    #print(xticks, xlabels);input()
    plt.xticks(xticks, xlabels)

    plt.yfrequency(5)

    plt.xlabel("%s - %s"%(fechas[0], fechas[-1]))
    plt.title("ATAQUES POR MES/AÑO (%s)"%band)
    plt.theme("clear")
    plt.show()

def temp3():
    #Ataques de todos por mes
    x = 0
    for i in tot:
        for p in i["Paises"]:
            if pais[0] == p:
                if i["Nombre"] in resultado:
                    resultado[i["Nombre"]] += 1
                else:
                    resultado[i["Nombre"]] = 1




