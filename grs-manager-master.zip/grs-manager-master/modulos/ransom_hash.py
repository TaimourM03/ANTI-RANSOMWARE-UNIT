from random import randint
import socket
from tqdm import tqdm
import os
from os import system
from termcolor import cprint
from pyfiglet import figlet_format
import json
from time import sleep

# Variables #################
vars_file = open("vars.json")
env = json.load(vars_file)

remote_ip = env["mongo_ip"]
###############################

def menu():
    fonts = ["ivrit", "mini", "script", "shadow", "slant", "small",
            "standard"]
    colors = ["red", "blue", "white", "yellow"]
    n = randint(0, len(fonts)-1)
    cn = randint(0, len(colors)-1)
    cprint(figlet_format('Ransom Hashes', font=fonts[n]), colors[cn])

def clear():
    system("clear")

def sendFile(file):

    if os.path.exists(file):
        fileName = file.split("/")[-1] 
        fileSize = os.path.getsize(file)
        separator = "<newFile>"
        fileInfo = fileName+separator+str(fileSize)

        host = remote_ip
        port = 9999
        buffer = 4096

        client_socket = socket.socket()
        client_socket.connect((host, port))
        client_socket.send(fileInfo.encode())
        client_socket.recv(1024) # Debug
        with open(file, "rb") as f:
            while True:
                bytes_read = f.read(buffer)
                if not bytes_read:
                    break
                client_socket.sendall(bytes_read)
            client_socket.close()
    else:
        pass

def RemoteAnalysis():
    host = remote_ip
    port = 9999
    buffer = 4096

    info = "analyzeHash"
    client_socket = socket.socket()
    client_socket.connect((host, port))
    client_socket.send(info.encode())
    client_socket.recv(1024) # Debug

    print(client_socket.recv(1024).decode())

    total = int(client_socket.recv(1024).decode())

    for i in tqdm(range(total)):
        response = client_socket.recv(1024).decode()
        if response == "null":
            pass
        else:
            tqdm.write(response)
    client_socket.close()

def hashes():
    system('clear')
    menu()
    cmd = ""
    while cmd != "exit":
        cmd = input("garu@ransom-hashes > ")
        if "fuzzy " in cmd:
            file = cmd.split(" ")[1].replace("'", "")
            if os.path.exists(file):
                sendFile(file)
                sleep(3)
                RemoteAnalysis()
            else:
                print("El fichero seleccionado no existe")
        elif cmd == "clear":
            clear()
        elif cmd == "?" or cmd == "help":
            print()
            print("     fuzzy [hash | path-to-file]     Busca similitudes en la base de datos\n")
            print("     clear                           Limpia la terminal\n")
            print("     ?                               Muestra este mensaje de ayuda\n")
            print("     exit                            Sale del módulo de hashes\n")
        else:
            pass
