from datetime import datetime as dt
from terminaltables import AsciiTable
from time import sleep
import pymongo
import subprocess
from os import system

from modulos.ransomdb_admin import show_tab
from modulos.completer import *
from modulos.templates import *

import shutil

import plotext as plt
import json

# Variables #################################################################
vars_file = open("vars.json")
env = json.load(vars_file)

mongo_ip = env["mongo_ip"]
mongo_port = env["mongo_port"]
mongo_db = env["mongo_db"]
mongo_collection = env["mongo_collection"]
mongo_user = env["mongo_user"]
mongo_password = env["mongo_password"]

cliente = pymongo.MongoClient("mongodb://%s:%s@%s:%s"%(mongo_user, mongo_password, mongo_ip, mongo_port))
ransom_db = cliente[mongo_db]
bandas = ransom_db[mongo_collection]
###############################################################################
def clear():
    system("clear")

def ayuda():
    print()
    print("     shall               Muestra todos los proyectos generados\n")
    print("     crear [Nom_Proy]    Crea un nuevo proyecto\n")
    print("     open [ID]           Abre un proyecto ya existente\n")
    print("     rm [ID]             Elimina un proyecto\n")
    print("     pdf [ID]            Genera un reporte en formato PDF\n")
    print("     clear               Limpia la terminal\n")
    print("     help, ?             Muestra este mensaje de ayuda\n")
    print("     exit                Salir\n")

def vista(banda, busqueda, campo):
    x = bandas.find_one({"Nombre" : banda})
    t = [["ID", "Empresas", "Fechas", "Paises", "Continentes"]]
    emp = x["Empresas"]
    fec = x["Fechas"]
    pai = x["Paises"]
    con = x["Continentes"]
    for i in range(len(emp)):
        #print(busqueda, x[campo][i])
        if campo == "Fechas":
            if busqueda == x[campo][i].split("-")[1]: # Mes
                t.append([i, emp[i], fec[i], pai[i], con[i]])
            elif busqueda == x[campo][i].split("-")[2]: # Año
                t.append([i, emp[i], fec[i], pai[i], con[i]])
            elif busqueda == x[campo][i].split("-")[1]+"-"+x[campo][i].split("-")[2]:
                t.append([i, emp[i], fec[i], pai[i], con[i]])
        elif campo == "Nombre":
            t.append([i, emp[i], fec[i], pai[i], con[i]])
        else:
            if busqueda == x[campo][i]:
                t.append([i, emp[i], fec[i], pai[i], con[i]])

    if len(t) > 1:
        table = AsciiTable(t)
        print(table.table)
        return t
    else:
        print("\n[!] No se han encontrado coincidencias\n")
        return ""

def sub_vista(sub, busqueda):
    #sub es una lista
    t = [["ID", "Empresas", "Fechas", "Paises", "Continentes"]]
    for i in sub:
        for e in i:
            #print(busqueda, e, type(e))
            if type(e) != int:
                if busqueda in e:
                    t.append(i)

    if len(t) > 1:
        table = AsciiTable(t)
        print(table.table)
        return t
    else:
        print("\n[!] No se han encontrado coincidencias\n")
        return ""

def rm(cmd):
    home = str(subprocess.check_output("echo $HOME", shell=True)).replace("\\n", "").replace("'", "").replace("b", "")
    proyecto = cmd.split(" ")
    ind = int(proyecto[1])
    if len(proyecto) == 2:
        if int(proyecto[1]) < len(os.listdir(home+"/ransom-reports")):
            proys = os.listdir(home+"/ransom-reports")
            print("[!] Estas a punto de eliminar el proyecto '%s'. Se eliminaran todos los archivos"%proys[ind])
            conf = input("Para continuar con esta acción, introduce el nombre de este proyecto: ")
            if conf == proys[ind]:
                dir_proyecto = home+"/ransom-reports/"+proys[ind]
                shutil.rmtree(dir_proyecto)
                print("[!] El proyecto '%s' se ha eliminado con exito"%proys[ind])
            else:
                print("[!] Operacion abortada")
    else:
        print("[!] Sintaxis incorrecta")


def crear(cmd):
    home = str(subprocess.check_output("echo $HOME", shell=True)).replace("\\n", "").replace("'", "").replace("b", "")
    proyecto = ""
    if "crear" in cmd:
        p = cmd.replace("crear ", "")
        
        for i in p:
            if i == " ":
                proyecto += "_"
            else:
                proyecto += i
        if os.path.exists(home+"/ransom-reports"):
            pass
        else:
            system("mkdir ~/ransom-reports")
        if os.path.exists(home+"/ransom-reports/%s"%proyecto):
            print("[*] Error: ya existe un proyecto con ese nombre")
            return 0
        else:
            system("mkdir ~/ransom-reports/%s"%proyecto)
        dir_proyecto = home+"/ransom-reports/"+proyecto+"/"
    elif "open" in cmd:
        pro = cmd.split(" ")
        if len(pro) == 2:
            if int(pro[1]) < len(os.listdir(home+"/ransom-reports")):
                proys = os.listdir(home+"/ransom-reports")
                for i in range(len(proys)):
                    if i == int(pro[1]):
                        proyecto = proys[i]
                        dir_proyecto = home+"/ransom-reports/"+proys[i]+"/"
            else:
                print("[!] ID no identificado")
        else:
            print("[!] Sintaxis incorrecta")

    cmd = ""
    while cmd != "exit":
        cmd = input("garu@reports[%s] > "%proyecto)
        if cmd == "help" or cmd == "?":
            print()
            print("     load            Permite ver y/o cargar información de una banda al proyecto actual\n")
            print("     intel [ID]      Informacion general predefinida\n")
            print("     see             Permite ver la información cargada en el proyecto actual\n")
            print("     undo            Permite deshacer la ultima carga de información\n")
            print("     edit            Permite una edición manual usando vim\n")
            print("     clear           Limpia la terminal\n")
            print("     help, ?         Muestra este mensaje de ayuda\n")
            print("     exit            Salir\n")
        elif cmd == "intel":
            print()
            print("     [0] Total de ataques por paises")
            print("     [1] Total de ataques en un pais")
            print("     [2] Trayectoria delectiva")
            print()
        elif "intel " in cmd:
            tmp = cmd.split(" ")
            if len(tmp) == 1:
                pass
            elif len(tmp) == 2:
                if int(tmp[1]) <= 2 and int(tmp[1]) >= 0:
                    opc = tmp[1]
                    if opc == "0":
                        system("python3 -c 'from modulos.templates import *; temp0()'")
                    elif opc == "1":
                        system("python3 -c 'from modulos.templates import *; temp1()'") 
                    elif opc == "2":
                        system("python3 -c 'from modulos.templates import *; temp2()'") 
                else:
                    print("[!] Opcion invalida")


            else:
                print("[!] Sintaxis incorrecta")
        elif cmd == "see":
            info = os.listdir(dir_proyecto)
            if len(info) == 0:
                print("[!] Aún no se añade información al proyecto")
            else:
                for i in range(len(info)):
                    print("[%s] %s"%(i, info[i]))
                    #for m in meta:
                    #    print("     [x] %s"%meta)

        elif cmd == "load": 
            b = complete("bandas")
            print("[+] %s se ha cargado"%b)
            cmd = ""
            temp = []
            info = {}
            sub = False
            subcont = []
            sub_metadt = ""
            while cmd != "end":
                #print(subcont)
                if sub == False:
                    cmd = input("garu@reports[%s][load][%s] > "%(proyecto, b))
                else:
                    cmd = input("garu@reports[%s][load][%s][🟢] > "%(proyecto, b))

                if cmd == "ayuda" or cmd == "?":
                    print()
                    print("     shall               Muestra todos los registros\n")
                    print("     describe            Muestra una descripcion de %s\n"%b)
                    print("     pais                Filtrado por paises\n")
                    print("     continent           Filtrado por continentes\n")
                    print("     date [DD-MM-AAAA]   Filtrado por fecha\n")
                    print("         -m [MM]             Filtrado por mes\n")
                    print("         -a [AAAA]           Filtrado por año\n")
                    print("     sub                 Permite hacer subconsultas sobre la última consulta\n")
                    print("     subf                Termina con el modo de subconsultas\n")
                    print("     add                 Añade la última consulta al proyecto actual\n")
                    print("     clear               Limpia la terminal\n")
                    print("     help, ?             Muestra este mensaje de ayuda\n")
                    print("     end                 Termina la carga de información\n")
                elif cmd == "sub":
                    sub = True
                    print("[+] Modo subconsulta activado. Use 'subf' al terminar")
                    subcont = temp[1]
                    sub_metadt += temp[0]+" -> "
                elif cmd == "subf":
                    temp = ["Subconstulta [%s]"%sub_metadt, subcont]
                    subcont = []
                    sub_metadt = ""
                    sub = False
                    print("[-] Modo subconsulta desactivado. Use 'add' para añadir resultados al proyecto actual")
                elif cmd == "describe":
                    bdes = b.lower().replace(" ", "_")
                    system("wget http://%s:1111/infogfs/%s.md"%(mongo_ip, bdes))
                    clear()
                    txt = open("%s.md"%bdes, "r")
                    c = 0
                    texto = []
                    for i in txt:
                        print(i.replace("*", "").replace("#", ""))
                        texto.append(i.replace("*", "").replace("#", ""))
                    temp = ["describe", texto]
                    txt.close()
                    os.remove("%s.md"%bdes) 
                elif cmd == "shall":
                    res_all = vista(b, "all", "Nombre")
                    temp = ["Todos los registros", res_all]
                elif cmd == "pais":
                    usr_p = complete("paises")[0]
                    if sub == True:
                        subcont = sub_vista(subcont, usr_p)
                        sub_metadt +=  "-> %s"%usr_p
                    else:
                        res_pais = vista(b, usr_p, "Paises")
                        temp = ["Ataques en %s"%usr_p, res_pais]
                elif cmd == "continent":
                    usr_c = complete("continentes")
                    if sub == True:
                        subcont = sub_vista(subcont, usr_c)
                        sub_metadt +=  "-> %s"%usr_c
                    else:
                        res_con = vista(b, usr_c, "Continentes")
                        temp = ["Ataques en %s"%usr_c, res_con]
                elif "date " in cmd:
                    if "-m" in cmd and "-a" in cmd:
                        mes_a = cmd.split(" ")
                        mes = ""
                        año = ""
                        for i in range(len(mes_a)):
                            if mes_a[i] == "-a":
                                try:
                                    año = mes_a[i+1]
                                except:
                                    print("[!] El parametro de '-a' es obligatorio [AAAA]")
                            elif mes_a[i] == "-m":
                                try:
                                    mes = mes_a[i+1]
                                except:
                                    print("[!] El parametro de '-m' es obligatorio [MM]")
                        if año != "" and mes != "":
                            if len(mes) == 2 and int(mes) <= 12 and len(año) == 4:
                                mes_a = "%s-%s"%(mes, año)
                                if sub == True:
                                    subcont = sub_vista(subcont, mes_a)
                                    sub_metadt +=  "-> mes-año: %s"%mes_a
                                else:
                                    res_am = vista(b, mes_a, "Fechas")
                                    temp = ["Filtro por mes %s y año %s"%(mes, año), res_am]
                    elif "-m" in cmd or "-a" in cmd:
                        if "-m" in cmd:
                            mres = ""
                            mes = cmd.split(" ")
                            for i in range(len(mes)):
                                if mes[i] == "-m":
                                    try:
                                        mres = mes[i+1]
                                    except:
                                        print("[!] El parametro de '-m' es obligatorio [MM]")
                                    else:
                                        if len(mres) == 2 and int(mres) <= 12:
                                            if sub == True:
                                                subcont = sub_vista(subcont, "-%s-"%mres)
                                                sub_metadt +=  "-> Mes: %s"%mres
                                            else:
                                                resm = vista(b, mres, "Fechas")
                                                temp = ["Filtro por mes %s"%mres, resm]
                                        else:
                                            print("[!] Sólo se aceptan valores entre '01' y '12'")
                        elif "-a" in cmd:
                            ares = ""
                            año = cmd.split(" ")
                            for i in range(len(año)):
                                if año[i] == "-a":
                                    try:
                                        ares = año[i+1]
                                    except:
                                        print("[!] El parametro de '-a' es obligatorio [AAAA]")
                                    else:
                                        if len(ares) == 4:
                                            if sub == True:
                                                subcont = sub_vista(subcont, ares)
                                                sub_metadt +=  "-> Año: %s"%ares
                                            else:
                                                res_a = vista(b, ares, "Fechas")
                                                temp = ["Filtro por año %s"%ares, res_a]
                                        else:
                                            print("[!] El formato aceptado para el año es 'AAAA'")
                    else:
                        fec = cmd.split(" ")
                        if len(fec) > 1:
                            #print(fec, fec[1].split("-"))
                            if len(fec[1].split("-")) == 3:
                                fec = fec[1]
                                if sub == True:
                                    subcont = sub_vista(subcont, fec)
                                else:
                                    res_date = vista(b, fec, "Fechas")
                                    temp = ["Filtro por fecha %s"%fec, res_date]
                            else:
                                print("[!] Sintaxis incorrecta")
                elif cmd == "clear":
                    clear()
                elif cmd == "add":
                    if temp[1] != "":
                        info[temp[0]] = temp[1]
                        print("[+] Añadido correctamente [%s]"%temp[0])
                    else:
                        print("[!] Nada que añadir")
                elif cmd == "end":
                    if info != {}:
                        txt = open(dir_proyecto+b, "a")
                        txt.write("[+] %s\n"%dt.now())
                        txt.write(str(info))
                        txt.write("\n")
                        txt.close()
        elif cmd == "clear":
            clear()

def reports():
    cmd = ""
    home = str(subprocess.check_output("echo $HOME", shell=True)).replace("\\n", "").replace("'", "").replace("b", "")
    while cmd != "exit":
        cmd = input("garu@reports > ")
        if cmd == "help" or cmd == "?":
            ayuda()
        elif "rm " in cmd:
            rm(cmd)
        elif "crear " in cmd:
            crear(cmd)
        elif "open " in cmd:
            crear(cmd)
        elif cmd == "shall":
            x = os.listdir(home+"/ransom-reports")
            if len(x) == 0:
                print("[!] Aun no se han añadido proyectos")
            else:
                for i in range(len(x)):
                    print("     [%s]    %s"%(i, x[i]))
        elif cmd == "":
            pass
        elif cmd == "exit":
            pass
        elif cmd == "clear":
            clear()
