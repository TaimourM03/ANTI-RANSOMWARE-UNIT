import socket
import os
from tqdm import tqdm

def sendFile(file):

    if os.path.exists(file):

        fileSize = os.path.getsize(file)
        separator = "<newFile>"
        fileInfo = file+separator+str(fileSize)

        host = "127.0.0.1"
        port = 9999
        buffer = 4096

        client_socket = socket.socket()
        client_socket.connect((host, port))
        client_socket.send(fileInfo.encode())

        with open(file, "rb") as f:
            while True:
                bytes_read = f.read(buffer)
                if not bytes_read:
                    break
                client_socket.sendall(bytes_read)
            client_socket.close()
    else:
        pass

def RemoteAnalysis():
    host = "127.0.0.1"
    port = 9999
    buffer = 4096

    info = "analyzeHash"
    client_socket = socket.socket()
    client_socket.connect((host, port))
    client_socket.send(info.encode())

    print(client_socket.recv(1024).decode())

    total = int(client_socket.recv(1024).decode())

    for i in tqdm(range(total)):
        response = client_socket.recv(1024).decode()
        if response == "null":
            pass
        else:
            tqdm.write(response)
    client_socket.close()
#sendFile("testme.docx")
#RemoteAnalysis()


