import requests
from bs4 import BeautifulSoup as bs

def Bianlian():
	corps=[]
	dates=[]
	websites=[]

	url="http://bianlianlbc5an4kgnay3opdemgcryg2kpfcbgczopmm3dnbz3uaunad.onion/companies/"
	session = requests.session()
	session.proxies["http"] = "socks5h://localhost:9050"
	session.proxies["https"] = "socks5h://localhost:9050"
	response = session.get(url)
	soup = bs(response.content, "html.parser")
	companies=soup.find_all("li", class_= "post")
	
	for data in companies:
		corps.append(data.a.get_text())
		dates.append(data.span.get_text())
		websites.append(data.a.get("href").replace("/", "").replace("companies", ""))
	
	return [corps, websites]
