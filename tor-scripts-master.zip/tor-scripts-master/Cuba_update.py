from datetime import datetime as dt
import requests
from time import sleep
from bs4 import BeautifulSoup as bs
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from Conversor_fechas import date_convertor as d_c
from get_paises import obtener_pais as o_p

def Cuba():
	links_corps=[]
	names=[]
	dates=[]
	webs=[]

        #url="http://localhost:1111/cuba.html"
	url="http://cuba4ikm4jakjgmkezytyawtdgr2xymvy6nvzgw5cglswg3si76icnqd.onion/category/free/"
	session = requests.session()
	session.proxies["http"] = "socks5h://localhost:9050"
	session.proxies["https"] = "socks5h://localhost:9050"
	response = session.get(url)
	soup = bs(response.content, "html.parser")
      	#recoleccion de links de empresa de la primera pagina
	divs=soup.find_all("div", class_="list-text")

	for links in divs:
		link=links.a.get("href")
		links_corps.append(link)
             	#print(link)#

	#recoleccion de links de las otras paginas
	pages=soup.find_all("a", class_="page-numbers")

	for link in pages:
		page=link.get("href")
		response = session.get(page)
		sub_page = bs(response.content, "html.parser")
		divs=sub_page.find_all("div", class_="list-text")
		#recoleccion de links de empresa de las otras paginas
		for links in divs:
			l=links.a.get("href")
			links_corps.append(l)

	#para sacar la informacion de cada ataque
	c=0
	while c==0:
		try:
			for link in links_corps:
				response=session.get(link)
				corporation = bs(response.content, "html.parser")
				name=corporation.find("div", class_="page-h1").span.get_text()
				if name not in names:
					names.append(name)
					data=corporation.find_all("p")
					for x in data:
						new=x.get_text()
						if(new.startswith("website")==True):
							web=new.replace("website: ", "").replace("http://", "").replace("https://", "").replace("www.", "").replace("\xa0", "").replace("website:", "").replace(" ", "")
							if(web.endswith("/") and web not in webs):
								webs.append(web[:-1])
							elif web not in webs:
								webs.append(web)
							else:
								webs.append("null")
			c=1
		except:
			c=0
	session.close()
	return [names, webs]
