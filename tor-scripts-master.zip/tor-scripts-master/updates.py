############## DEPENDENCIAS ##################
from time import sleep
from datetime import datetime as dt
import pymongo
from telbot import send_to_bot
from get_paises import obtener_pais as o_p
from os import system
##############################################


############## MODULOS ##################
#from RedAlert_update import *
#from basta_update import *
from Babuk_update import *
from BlackCat_update import *
from CL0P_update import *
#from Cheers_update import *
#from Cuba_update import *
from Everest_update import *
#from Hive_update import *
from Karakurt_update import *
#from LV_update import *
#from LockBit_update import *
from Lorenz_update import *
#from MosesStaff_update import *
from Quantum_update import *
#from RagnarLocker_update import *
#from RansomHouse_update import *
from Ransomxx_update import *
#from Snatch_update import *
from Suncrypt_update import *
#from Yanluowang_update import *
from BianLian_update import *
from ViceSociety_update import *
from Omega_update import *
##############################################


############### VARIABLES ####################
mongo_ip="ransomdb-docker"
mongo_port="27017"
mongo_db="ransom"
mongo_collection="bandas"
mongo_user="garu"
mongo_password="garu"
############################################

cliente = pymongo.MongoClient("mongodb://%s:%s@%s:%s"%(mongo_user, mongo_password, mongo_ip, mongo_port))
ransomdb = cliente[mongo_db]
bandas = ransomdb[mongo_collection]

tot = bandas.find()

def update_db(banda, lista):
    x = bandas.find_one({"Nombre" : banda})
    emp = x["Empresas"]
    fec = x["Fechas"]
    pai = x["Paises"]
    con = x["Continentes"]
    #print(emp, fec, pai, con)
    #print(emp, fec, pai, con)
    #input()
    #input()
    for i in range(len(lista)):
        emp.append(lista[i][0])
        fec.append(lista[i][1])
        pai.append(lista[i][2][0])
        con.append(lista[i][3][0])
    
    b = {"Nombre" : banda}
    datos_n = {"$set" : {"Empresas" : emp, "Fechas" : fec, "Paises" : pai, "Continentes" : con}}
    bandas.update_one(b, datos_n)

def update(banda, lista_n):
    if lista_n[0] != []:
        x = bandas.find_one({"Nombre" : banda})
        lista_db = x["Empresas"]
        #print(banda, x);input()
        nuevos = []
        for i in range(len(lista_n[0])):
            if lista_n[0][i] not in lista_db:
                #nuevos.append([lista_n[0][i], lista_n[1][i]])
                
                #print(banda, lista_n[0][i]);input()
                
                locat = o_p([lista_n[1][i]])
                nuevos.append([lista_n[0][i], dt.now().strftime('%d-%m-%Y'), locat[0], locat[1]])
                msn = "%s\nCompany: %s\nDate: %s\nCountry: %s"%(banda, str(lista_n[0][i]), dt.now().strftime('%d-%m-%Y'), locat[0][0])
                send_to_bot(msn)
        if len(nuevos) > 0:
            #print(nuevos);input()
            update_db(banda, nuevos)
            pass
        else:
            print("Sin cambios")

#"""
while True:
    #try:
    #    update("Red Alert", RedAlert())
    #except Exception as ex:
    #    print(ex)
    try:
        update("Black Basta", session())
    except Exception as ex:
        print(ex)
    try:
        update("Babuk", BabukLocker())
    except Exception as ex:
        print(ex)
    try:
        update("Black Cat", BlackCat())
    except Exception as ex:
        print(ex)
    try:
        update("CL0P", CL0P())
    except Exception as ex:
        print(ex)
    try:
        update("Cheers", Cheers())
    except Exception as ex:
        print(ex)
    #try:
    #    update("Cuba", Cuba())
    #except Exception as ex:
    #    print(ex)
    try:
        update("Everest", Everest())
    except Exception as ex:
        print(ex)
    #update("Hive", Hive())
    try:
        update("Karakurt", Karakurt())
    except Exception as ex:
        print(ex)
    try:
        update("LV", LV())
    except Exception as ex:
        print(ex)
    
    try:
        update("Lockbit", LockBit())
    except Exception as ex:
        print(ex)
    try:
        update("Lorenz", Lorenz())
    except Exception as ex:
        print(ex)
    try:
        update("Moses Staff", Moses())
    except Exception as ex:
        print(ex)
    try:
        update("Quantum", Quantum())
    except Exception as ex:
        print(ex)
    try:
        update("Ragnar Locker", Ragnar())
    except Exception as ex:
        print(ex)
    try:
        update("Ransom House", RansomHouse())
    except Exception as ex:
        print(ex)
    try:
        update("Ransomxx", RansomXX())
    except Exception as ex:
        print(ex)
    #update("Snatch", Snatch())
    try:
        update("Suncrypt", Suncrypt())
    except Exception as ex:
        print(ex)
    try:
        update("Yanluowang", Yanluowang())
    except Exception as ex:
        print(ex)
    try:
        update("BianLian", Bianlian())
    except Exception as ex:
        print(ex)
    try:
        update("Vice Society", Vice())
    except Exception as ex:
        print(ex)
    try:
        update("Omega", Omega())
    except Exception as ex:
        print(ex)
        
    system("killall chrome")
    sleep(3000)
#"""
