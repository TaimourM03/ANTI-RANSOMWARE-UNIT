import requests
from datetime import datetime as dt
from tqdm import tqdm
from bs4 import BeautifulSoup as bs
from get_paises import obtener_pais as o_p
from Conversor_fechas import date_convertor as d_c

#Nos conectamos a la web y creamos el objeto soup
def conec_main(url,empresas,fechas):
    linkz = []
    links = []
    session = requests.session()
    session.proxies["http"] = "socks5h://localhost:9050"
    session.proxies["https"] = "socks5h://localhost:9050"
    session.close()
    response = session.get(url)
    soup = bs(response.content, "html.parser")
    css_soup_links = soup.find_all('a[class="page-link"]')
    #Añadimos todos los links que hay en la pagina
    for link in soup.find_all('a'):
        #Especificamos que solo queremos los links que sean para cambiar pagina, que comparten la palabra "page"
        if "page=1" not in str(link.get('href')) and "page" in str(link.get("href")):
            linkz.append(url+link.get('href'))  #Añadimos el "https:" al link.
    empresas, fechas, links = analizador(links,soup,empresas,fechas)
    empresas, fechas, links = conec_webs(links,linkz,empresas,fechas)
    return empresas, fechas, links

#Conectamos todas las webs que no sean la principal
def conec_webs(links,linkz,empresas,fechas):
    for i in linkz:
        session = requests.session()
        session.proxies["http"] = "socks5h://localhost:9050"
        session.proxies["https"] = "socks5h://localhost:9050"
        session.close()
        response = session.get(i)
        soup = bs(response.content, "html.parser")
        empresas, fechas, links = analizador(links,soup,empresas,fechas)
    return empresas, fechas, links

#analizamos las webs y obtenemos los datos que nos interesan
def analizador(links,soup,empresas,fechas):
    soup_fechas = soup.find_all("p",{"class":"card-text mt-3 text-secondary"})
    soup_empresas = soup.find_all("h5",{"class":"card-title"})
    soup_links = soup.find_all("p",{"class":"card-text"})
    for link in soup_links:
        if "</a>" in str(link):
            link=str(link.select("a")).split('href="')[1].split('">')[0].replace("https:", "").replace("http:", "").replace("/", "").replace("www.", "")
            links.append(link)
    for z in soup_fechas: 
        liz = z.text.split(",")
        li = liz[0].split("published: ")
        fechas.append(li[1])
    for m in soup_empresas:
        empresas.append(m.text)
    return empresas, fechas, links

def RansomXX():
    url = "http://rnsm777cdsjrsdlbs4v5qoeppu3px6sb2igmh53jzrx7ipcrbjz5b2ad.onion"
    empresas = []
    fechas = []
    empresas, fechas, links = conec_main(url,empresas,fechas)
    #locat = o_p(links)
    #fechas = d_c(fechas)
    return [empresas, links]
