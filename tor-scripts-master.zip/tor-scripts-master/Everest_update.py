from datetime import datetime as dt
import requests
from bs4 import BeautifulSoup as bs
from get_paises import obtener_pais as o_p

def Everest():
        links=[]
        names = []
        webs=[]
        pages=1
        l=""

        while True:
                url = "http://ransomocmou6mnbquqz44ewosbkjk3o5qjsl3orawojexfook2j7esad.onion"+l
                #Nos conectamos a la web y creamos el objeto soup
                pages=pages+1
                l="/page/"+str(pages)
                session = requests.session()
                session.proxies["http"] = "socks5h://localhost:9050"
                session.proxies["https"] = "socks5h://localhost:9050"
                response = session.get(url)
                soup = bs(response.content, "html.parser")
                if(soup.h1.get_text()=="Page Not Found"):
                        break
                else:
                        for link in soup.find_all("h2"):
                                try:
                                        if(link.a.get("href")!="http://ransomocmou6mnbquqz44ewosbkjk3o5qjsl3orawojexfook2j7esad.onion/news/"):
                                                links.append(link.a.get("href"))
                                        else:
                                                continue
                                except:
                                        break

        for l in links:
                url=l
                session = requests.session()
                session.proxies["http"] = "socks5h://localhost:9050"
                session.proxies["https"] = "socks5h://localhost:9050"
                response = session.get(url)
                soup = bs(response.content, "html.parser")
                data=soup.find_all("td")
                for website in data:
                        web=website.get_text()
                        if(web.startswith("https://dropmefil")):
                                names.append(soup.h1.get_text())
                                webs.append("null")
                        elif(web.startswith("http")):
                                w=web.replace("www.", "").replace("https://", "").replace("http://", "")
                                names.append(soup.h1.get_text())
                                if (w.endswith("/")):
                                        webs.append(w[:-1])
                                else:
                                        webs.append(w)
                                if(web.startswith("http")):
                                        names.append(soup.h1.get_text())
                                        webs.append(web)
                        else:
                                continue
        #locat = o_p(webs)
        #fechas=[]
        #for m in range(len(names)):
        #        fechas.append("Desconocido")
        empresas = []
        for i in names:
            if i not in empresas:
                empresas.append(i)
        excps = ["data from other automobile concerns", "PLC Files Leak", "evelopments Files Leak", "Fedfina.part2"]
        for e in excps:
            for i in range(len(empresas)):
                if e in empresas[i]:
                    del empresas[i]
                    del webs[i]
                    break
        session.close()
        return [empresas, webs]
