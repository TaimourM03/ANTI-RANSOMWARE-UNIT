import requests
from get_paises import obtener_pais as o_p
from datetime import datetime as dt
from tqdm import tqdm
from bs4 import BeautifulSoup as bs
from Conversor_fechas import date_convertor as d_c

def BabukLocker():
        url = "http://nq4zyac4ukl4tykmidbzgdlvaboqeqsemkp4t35bzvjeve6zm2lqcjid.onion" 
        corps = []
        dates = []
        webs =[]
        session = requests.session()
        session.proxies["http"] = "socks5h://localhost:9050"
        session.proxies["https"] = "socks5h://localhost:9050"
        response = session.get(url)
        soup = bs(response.content, "html.parser")    

        attacks=soup.find_all("a", class_ ="leak-card p-3")

        for data in attacks:
                corp=data.h5.get_text().split(" ")
                if(("Babuk" in corp) or ("babuk" in corp) or ("BABUK" in corp)):
                        continue
                else:
                        name=" ".join(corp)
                        corps.append(name)
                        date=data.find("div", class_ ="col-auto published").get_text().replace(" ", "").replace("\n", "")[:-8]
                        date = date[8:10:]+date[4:7:]+"-"+date[:-6]
                        dates.append(date)
                        description=data.p.get_text()
                        if(description.startswith("http")):
                                link=description.replace("https://www.", "")
                                if (link.endswith("/")):
                                        webs.append(link[:-1])
                                else:
                                        webs.append(link)
                        elif(name.endswith(".com")):
                                webs.append(name)
                        else:
                                sublink=data.get("href")
                                response = session.get(url+sublink)
                                soup = bs(response.content, "html.parser")
                                sentence=soup.find_all("p")
                                for thing in sentence:
                                        list_t=thing.get_text().split(" ")
                                        for web in list_t:
                                                if(web.startswith("htt")):
                                                        webs.append(web[:-1].replace("http://", "").replace("www.", ""))
                                                else:
                                                        continue        
        #locat=o_p(webs)                 
        #dates = d_c(dates)
        #return [corps, dates, locat[0] , locat[1]]
        session.close()
        return [corps, webs]
