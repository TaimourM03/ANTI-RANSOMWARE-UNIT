from datetime import datetime as dt
import requests
from bs4 import BeautifulSoup as bs
import tqdm
from get_paises import obtener_pais as o_p
def BlackByte():
        url="http://ce6roic2ykdjunyzazsxmjpz5wsar4pflpoqzntyww5c2eskcp7dq4yd.onion/"
        session = requests.session()
        session.proxies["http"] = "socks5h://localhost:9050"
        session.proxies["https"] = "socks5h://localhost:9050"
        response = session.get(url)
        soup = bs(response.content, "html.parser")
        corporations=soup.find_all("h1", class_ ="h_font")
        links = soup.find_all("div", {"class":'col-md-3 text-center'})
        webs = []
        corps=[]
        for link in links:
                if "http" in str(link):
                        link = str(link).split("://")[1].split("\'")[0].split("/")[0]
                        if "www" in link:
                                link = link.split("w.")[1]
                        webs.append(link)
        for y in corporations:
                corp=y.get_text()
                corps.append(corp)
        locat = o_p(webs)
        fechas = []
        for x in range(len(corps)):
                fechas.append("Desconocido")
        return [corps, webs] 

#BByte=BlackByte()
"""

def blackbyte(BByte):
    s = BlackByte()
    if BByte==s:
        txt = open("logs/bbyte.log", "a")
        txt.write("[=] Black Byte (%s)\n"%dt.now())
        txt.close()
    else:
        for i in s[0]:
            if i not in BByte[0]:
                pos=S[0].index(i)
		txt = open("logs/bbyte.log", "a")
                txt.write("[+] Black Byte (%s)\n"%dt.now())
                txt.write(str([i,s[1][pos],s[2][pos],s[3][pos]]))
                txt.close()
    return s"""
