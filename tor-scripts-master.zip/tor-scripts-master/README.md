# Tor Scripts

Tor Scripts es un proyecto escrito completamente en Python, cuyo objetivo es la creación de scripts para la recolección de información de nuevos ataques de ransomware. El funcionamiento es el siguiente:

```mermaid
sequenceDiagram
autonumber
updates.py ->> Tor Script: Llamada a función
Tor Script ->> Leak Site: Scrapping
Leak Site ->> Tor Script: Todos los ataques (raw)
Tor Script ->> updates.py: Todos los ataques (format)
updates.py ->> BBDD: ¿Qué ataques tienes registrados?
BBDD ->> updates.py: Tengo todos estos
updates.py ->> BBDD: Se envian los ataques no registrados
updates.py ->> Bot: Se envian notificaciones de los ataques no registrados
```

# Implementación con GRS 
Este repositorio esta pensado para funcionar en conjunto con el [servidor GRS](https://github.com/cgonzalezc21/grs-docker). Las instrucciones necesarias se pueden consultar en dicho repositorio.

# Implementación  
Para fines de prueba o implentación en otros entornos, se requiere llevar a cabo los siguientes pasos

1. Instala los paquetes necesarios

```
sudo apt install python3 pip git
```
2. Instala y configura [mongodb](https://www.mongodb.com/docs/manual/administration/install-on-linux/)

3. Clona este repositorio

```
git clone https://github.com/cgonzalezc21/grs-docker.git
```

4. Instala las dependencias

```
pip install -r requirements.txt
```

5. Configura las variables para la conexión a la base de datos [updates.py](./updates.py)

```python
############### VARIABLES ####################
mongo_ip="172.13.2.1"
mongo_port="27017"
mongo_db="ransom"
mongo_collection="bandas"
mongo_user="user"
mongo_password="P4assw0rd!"
############################################
```

6. Importa la base de datos inicial. Para más información sobre este procedimiento, consulta la documentación del [GRS](https://github.com/cgonzalezc21/grs-docker)

7. Crea un bot en telegram y configura la API-key en [telbot.py](./telbot.py)

8. Finalmente, prorgrama la ejecución de [updates.py](./updates.py) o ejecutalo manualmente

```
python3 updates.py
```
