import requests

bot_token = "bot6216336919:AAH7EvbydvfMn4-FiefZDhxx-G6iKZraw-g"
group_id = "-940199368"

def send_to_bot(msn):
    requests.post("https://api.telegram.org/%s/sendMessage?chat_id=%s&text=%s"%(bot_token, group_id, msn))
