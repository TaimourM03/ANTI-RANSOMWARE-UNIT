import requests
from bs4 import BeautifulSoup as bs
from time import sleep
from get_paises import obtener_pais as o_p
from Conversor_fechas import date_convertor as d_c

def Suncrypt():
    links=[]
    corps=[]
    dates=[]
    url="http://x2miyuiwpib2imjr5ykyjngdu7v6vprkkhjltrk4qafymtawey4qzwid.onion"
    session = requests.session()
    session.proxies["http"] = "socks5h://localhost:9050"
    session.proxies["https"] = "socks5h://localhost:9050"
    response = session.get(url)
    soup = bs(response.content, "html.parser")

    attacks=soup.find("div", class_ ="card mt-5")

    data=attacks.find_all("a")

    for corp in data:

        link=corp.get("href")
        links.append(url+"/"+link)
        corps.append(corp.get_text())
        #print(link, corp.get_text())

    links.reverse()
    corps.reverse()

    for l in links:
        c=0
        while c==0:
            try:
                response=session.get(l)
                soup=bs(response.content, "html.parser")
                date=soup.find("tr")
                d=list(date)[1]
                day=d.get_text()
                if (day==""):
                    day=dates[-1].split("-")
                    d=str(int(day[-1])+1)
                    dates.append(day[0]+"-"+day[1]+"-"+d)
                else:
                    dates.append(day)

                c=1
            except:
                c=0
    session.close()

    #dates=d_c(dates)
    #locat = o_p(webs)
    return [corps, links]
