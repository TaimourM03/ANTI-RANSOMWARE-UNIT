import requests
from datetime import datetime as dt
from tqdm import tqdm
from bs4 import BeautifulSoup as bs
from get_paises import obtener_pais as o_p
from Conversor_fechas import date_convertor as d_c
import time


#Nos conectamos a la web y creamos el objeto soup
def Vice():
    url = "http://vsociethok6sbprvevl4dlwbqrzyhxcxaqpvcqt5belwvsuxaxsutyad.onion/"
    links = []
    session = requests.session()
    session.proxies["http"] = "socks5h://localhost:9050"
    session.proxies["https"] = "socks5h://localhost:9050"
    response = session.get(url)
    soup = bs(response.content, "html.parser")

    empresas=[]
    x = 0

    for card in soup.find_all("td",{"valign":'top'}):
        x += 1
        if x != 1:
            #NOMBRES
            for nombre in card.find("font",{"size":"4","color":"#FFFFFF"}):
                empresas.append(nombre.text)
                #print("\nEmpresa: ",nombre.text)
            #LINKS         
            try:
                for link in card.find("font",{"size":"2","color":"#5B61F6"}):
                    link = link.text.split("/")[2]
                    if "www" in link:
                        link = link.split("w.")[1]
                    if nombre.text == "ALMANIE GROUP":
                        link = "almaniegroup.com"
                    #print("Link: ",link)
                    links.append(link)
            except:
                #print("error en link!")
                time.sleep(2)
                link = "null"
                links.append(link)
                #print(link)
    session.close()
    return [empresas,links]
    
