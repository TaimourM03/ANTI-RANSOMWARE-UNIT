from datetime import datetime as dt
import requests
from bs4 import BeautifulSoup as bs
import time
from get_paises import obtener_pais as o_p

def CL0P():
        url="http://santat7kpllt6iyvqbr7q4amdv6dzrh6paatvyrzl7ry3zm72zigf4ad.onion"
        session = requests.session()
        session.proxies["http"] = "socks5h://localhost:9050"
        session.proxies["https"] = "socks5h://localhost:9050"
        response = session.get(url)
        soup = bs(response.content, "html.parser")

        corps=soup.find_all("span", class_ ="g-menu-item-title")
        pos=0
        corporations=[]
        links=[]
        cont = 1
        for name in corps:
                if (pos>2):
                        links.append(name.text)
                        if "ARCHIVE2" in name.text:
                                links.pop(-1)
                        bussines=name.get_text()
                        corp=list(bussines)
                        for dot in corp:
                                if (dot=="."):
                                        pos=corp.index(dot)
                                        del corp[pos:len(corp)]
                                        corp_r=''.join(corp)
                                        corporations.append(corp_r)
                                        cont+=1
                        pos+=1
                else:
                        pos+=1

        #locat = o_p(links)
        #fechas = []
        #for z in range(len(corporations)):
        #        fechas.append("Desconocido") 
        session.close()
        return [corporations, links]
