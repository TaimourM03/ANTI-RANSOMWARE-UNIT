from datetime import datetime as dt
from requests_html import HTMLSession
from bs4 import BeautifulSoup as bs
from time import sleep
import urllib3
from get_paises import obtener_pais as o_p
from Conversor_fechas import date_convertor as d_c
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
#import requests


def LockBit():
        listz=[]
        corps=[]
        dates=[]
        div_list=[]
        url = "http://lockbitapt2yfbt7lchxejug47kmqvqqxvvjpqkmevv4l3azl3gy6pyd.onion/" # LockBit
        proxies = 'socks5h://localhost:9050'
        session = HTMLSession(browser_args=['--proxy-server = socks5h://localhost:9050'])
        r = session.get(url, proxies={'http' : proxies, 'https' : proxies})
        r.html.render(timeout=500, sleep=50)
        web=r.html.html
        soup= bs(web, "html.parser")
        session.close()
        #url="http://localhost:1111/test.html"
        #session=requests.session()
        #response=session.get(url)
        #soup=bs(response.content, "html.parser")
        
        name=soup.find_all("div", class_ ="post-title")
        for x in name:
                corp=x.get_text().replace(" ","")
                corps.append(corp.replace("\n",""))
        
        divs=soup.find_all("div", class_ ="updated-post-date")
        for x in divs:
                date_f=x.span.get_text().split(":")
                date=date_f[1].replace(",\xa0\xa0 ", "")[1:-2]
                dates.append(date)

        #locat = o_p(corps)
        #dates= d_c(dates)
        #return [corps,dates,locat[0],locat[1]]
        return [corps, corps]
