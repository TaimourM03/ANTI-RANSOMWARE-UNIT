import requests
import json
import datetime
from time import sleep
from bs4 import BeautifulSoup as bs
from get_paises import obtener_pais as o_p
from Conversor_fechas import date_convertor as d_c

def BlackCat():
        names=[]
        dates=[]
        webs=[]

        url="http://alphvmmm27o3abo3r2mlmjrpdmzle3rykajqc5xsj7j7ejksbpsa36ad.onion/api/blog/all-brief"
        #url="http://localhost:1111/BC.json"

        session = requests.session()
        session.proxies["http"] = 'socks5h://localhost:9050'
        session.proxies["https"] = 'socks5h://localhost:9050'
        response = session.get(url)
        f=response.json()
        for dicci in f["items"]:

                date=dicci["createdDt"]
                date_r = datetime.datetime.fromtimestamp(date/1000)
                d=str(date_r).split(" ")
                day=d[0]

                name=dicci["title"]

                if (name.startswith(" ")==True):
                        corp=name.replace(" ", "", 1)
                        dates.append(day)#dia de subida de datos
                else:
                        dates.append(day)#dia de subiuda de datos

                if(len(name.split("|"))>=2):
                        try:
                                if (name.split("|")[0].endswith(".com")==True or name.split("|")[0].endswith(".com ")==True):
                                        names.append(name.split("|")[1])#nombre de la empresa
                                        webs.append(name.split("|")[0].replace(" ","").replace("www.", "").lower())#nombre de la empresa
                                        #print("EMPRESA:", name.split("|")[1])#nombre de la empresa
                                        #print("WEB:", name.split("|")[0], "\n")#pagina web
                                elif(name.split("|")[1].endswith(".com")==True or name.split("|")[1].endswith(".com ")==True or name.split("|")[1].endswith(".au")==True or name.split("|")[1].endswith(".uk")==True or name.split("|")[1].endswith(".ro")==True  or name.split("|")[1].endswith(".hk")==True or name.split("|")[1].endswith(".DE")==True):
                                        names.append(name.split("|")[0])#nombre de la empresa
                                        webs.append(name.split("|")[1].replace(" ","").replace("www.", "").lower())#nombre de la empresa
                                        #print("EMPRESA:", name.split("|")[0])#nombre de la empresa
                                        #print("WEB:", name.split("|")[1], "\n")#pagina web
                                else:
                                        names.append(name)#nombre de la empresa
                                        webs.append("null")#en el caso de que no tenga pagina web
                                        #print("EMPRESA:", name)#nombre de la empresa
                                        #print("WEB: null\n")#en el caso de que no tenga pagina web
                        except:
                                names.append(name)#nombre de la empresa
                                webs.append("null")#en el caso de que no tenga pagina web
                                #print("EMPRESA:", name)#nombre de la empresa
                                #print("WEB: null\n")#en el caso de que no tenga pagina web
                elif(len(name.split("-"))==2):
                        try:
                                if(name.split("-")[0].endswith("hk")):
                                        corp="hk-"+name.split("-")[1]
                                        names.append(corp)#nombre de la empresa
                                        web=name.split("-")[0].replace("hk", "", 1).replace(" ","").replace("www.", "").lower()
                                        webs.append(web)#pagina web
                                        #print("EMPRESA:", "hk-"+name.split("-")[1])#nombre de la empresa
                                        #print("WEB:", name.split("-")[0].replace("hk", "", 1).replace(" ",""), "\n")#pagina web
                                elif(name.split("-")[1].endswith(".com")==True or name.split("-")[1].endswith(".com")==True or name.split("-")[1].endswith(".it")==True):
                                        names.append(name.split("-")[0])#nombre de la empresa
                                        webs.append(name.split("-")[1].replace(" ","").replace("www.", "").lower())#pagina web
                                        #print("EMPRESA:", name.split("-")[0])#nombre de la empresa
                                        #print("WEB:", name.split("-")[1].replace(" ",""), "\n")#pagina web
                                elif(name.split("-")[1].endswith(".ch)")):
                                        corp=name.split(" ")[0], name.split(" ")[1], name.split(" ")[2]
                                        corp2=" ".join(corp)
                                        names.append(corp2)#nombre de la empresa
                                        web=name.split(" ")[-1]
                                        web2=web.replace("(","").replace(")","").replace("www.", "").lower()
                                        webs.append(web2)#pagina web
                                        #print("EMPRESA", name.split("-")[0])#nombre de la empresa
                                        #print("WEB:", name.split("-")[1].replace(" ","")+name.split("-")[2].replace(" ",""), "\n")#pagina web
                                else:
                                        names.append(name)#nombre de la empresa
                                        webs.append("null")#en el caso de que no tenga pagina web
                                        #print("WEB: null\n")#en el caso de que no tenga pagina web
                        except:
                                names.append(name)#nombre de la empresa
                                webs.append("null")#en el caso de que no tenga pagina web
                                #print("WEB: null\n")#en el caso de que no tenga pagina web
                elif(name.endswith(".com") or name.endswith(".hk") or name.endswith(".net") or name.endswith(".ro") or name.endswith(".BR")):
                        names.append(name)#nombre de la empresa
                        webs.append(name.replace(" ","").replace("www.", "").lower())#en el caso de que no tenga pagina web
                        #print("EMPRESA:", name)#nombre de la empresa
                        #print("WEB:", name, "\n")#pagina web

                elif(len(name.split(" "))>=2):
                        if(name.split(" ")[0].endswith(".com")):
                                names.append(name.split(" ")[1])#nombre de la empresa
                                webs.append(name.split(" ")[0].replace(" ","").replace("www.", "").lower())#pagina web
                                #print("EMPRESA:", name.split(" ")[1])#nombre de la empresa
                                #print("WEB:", name.split(" ")[0], "\n")#pagina web
                        elif(name.split(" ")[1].endswith(".com")):
                                names.append(name.split(" ")[0])#nombre de la empresa
                                webs.append(name.split(" ")[1].replace(" ","").replace("www.", "").lower())#pagina web
                                #print("EMPRESA:", name.split(" ")[0])#nombre de la empresa
                                #print("WEB:", name.split(" ")[1], "\n")#pagina web
                        else:
                                try:
                                        if(name.split(" ")[2].endswith(".au)")):
                                                corp=name.split(" ")[0], name.split(" ")[1]
                                                corp2=" ".join(corp)
                                                names.append(corp2)#empresa
                                                web=name.split(" ")[2].replace("(","").replace(")","").replace("www.", "").lower()
                                                webs.append(web)#web
                                                #print("EMPRESA:", name.split(" ")[0], name.split(" ")[1])#nombre de la empresa
                                                #print("WEB:", name.split(" ")[2].replace("(","").replace(")",""), "\n")#pagina web
                                        elif(name.split(" ")[3].endswith(".ch)") or name.split(" ")[3].endswith(".edu)")):
                                                corp=name.split(" ")[0], name.split(" ")[1], name.split(" ")[2]
                                                corp2=" ".join(corp)
                                                names.append(corp2)#empresa
                                                web=name.split(" ")[3].replace("(","").replace(")","").replace("www.", "").lower()
                                                webs.append(web)#pagina web
                                                #print("EMPRESA:", name.split(" ")[0], name.split(" ")[1], name.split(" ")[2])#nombre de la empresa
                                                #print("WEB:", name.split(" ")[3].replace("(","").replace(")",""), "\n")#pagina web
                                        elif(name.split(" ")[4].endswith(".fr") or name.split(" ")[4].endswith(".com)") or name.split(" ")[4].endswith(".edu)")):
                                                corp=name.split(" ")[0], name.split(" ")[1], name.split(" ")[2], name.split(" ")[3]
                                                corp2=" ".join(corp)
                                                names.append(corp2)#nombre de la empresa
                                                web=name.split(" ")[4].replace("(","").replace(")","").replace("www.", "").lower()
                                                webs.append(web)#pagina web
                                                #print("EMPRESA:", name.split(" ")[0], name.split(" ")[1], name.split(" ")[2], name.split(" ")[3])#nombre de la empresa
                                                #print("WEB:", name.split(" ")[4].replace("(","").replace(")",""), "\n")#pagina web
                                        elif(name.split(" ")[5].endswith(".edu)")):
                                                corp=name.split(" ")[0], name.split(" ")[1], name.split(" ")[2]+name.split(" ")[3], name.split(" ")[4]
                                                corp2=" ".join(corp)
                                                names.append(corp2)#nombre de la empresa
                                                web=name.split(" ")[5].replace("(","").replace(")","").replace("www.", "").lower()
                                                webs.append(web)#pagina web
                                                #print("EMPRESA:", name.split(" ")[0], name.split(" ")[1], name.split(" ")[2]+name.split(" ")[3], name.split(" ")[4])#nombre de la empresa
                                                #print("WEB:", name.split(" ")[5].replace("(","").replace(")",""), "\n")#pagina web
                                        else:
                                                names.append(name)#nombre de la empresa
                                                webs.append("null")#en el caso de que no tenga pagina web
                                                #print("EMPRESA:", name)#nombre de la empresa
                                                #print("WEB: null\n")#en el caso de que no tenga pagina web
                                except:
                                        names.append(name)#nombre de la empresa
                                        webs.append("null")#en el caso de que no tenga pagina web
                                        #print("EMPRESA:", name)#nombre de la empresa
                                        #print("WEB: null\n")#en el caso de que no tenga pagina web
                else:
                        names.append(name)#nombre de la empresa
                        webs.append("null")#en el caso de que no tenga pagina web
                        #print("EMPRESA:", name)#nombre de la empresa
                        #print("WEB: null\n")#en el caso de que no tenga pagina web

        for x in names:
                pos=names.index(x)
                if(x.startswith(" ")):
                        b=x.replace(" ", "",1)
                        names[pos]=b
                else:
                        continue

        #locat = o_p(webs)
        #dates = d_c(dates)
        #return[names, dates, locat[0], locat[1]]
        exc = ["Duda Farm Fresh Foods", "TRISON","tgs.com.ar","(NYSE:"] # Aqui se van añadiendo las publicaciones repetidas
        for e in exc:
            for i in range(len(names)):
                if e in names[i]:
                    del names[i]
                    del webs[i]
                    break
        session.close()
        return[names, webs]
