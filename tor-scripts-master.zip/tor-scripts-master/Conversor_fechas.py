def date_convertor(dates):
	months={"jan":"01", "feb":"02", "mar":"03", "apr":"04", "may":"05", "jun":"06", "jul":"07", "aug":"08", "sep":"09", "oct":"10", "nov":"11", "dec":"12"}
	d_inv=[]
	nulos = ["null","Null","NULL",""," ","Desconocido","DESCONOCIDO","desconocido","DSC"]
	#dates es una variable que representa la lista de fechas de la banda
	for types in dates:
		pos=dates.index(types)
		if types in nulos:
			dates[pos]="Desconocido"
			continue
		type_1=types.split("/")
		type_2=types.split("-")
		type_3=types.split(" ")		
		if(len(type_3)>=3 or len(type_2)>=3):
			#esta parte sirve para cambiar el string de mes por el numero que este tiene y reestructurar la fecha
			try:
				f_year=int(type_2[0])
				l_year=0
			except:
				f_year=0
				l_year=int(type_3[2])
			if (f_year>1000):
				real_date=type_2[2]+"-"+type_2[1]+"-"+type_2[0]
				dates[pos]=real_date
			elif(f_year<1000):
				try:
					if(int(type_2[1])<12):
						real_date=type_2[0]+"-"+type_2[1]+"-"+type_2[2]
						dates[pos]=real_date
					else:
						real_date=type_2[1]+"-"+type_2[0]+"-"+type_2[2]
						dates[pos]=real_date
				except:
					try:
						try:
							real_date=type_3[0]+"-"+months[type_3[1][0:3].lower()]+"-"+type_3[2]
							dates[pos]=real_date
						except:
							real_date=type_2[0]+"-"+months[type_2[1][0:3].lower()]+"-"+type_2[2]
							dates[pos]=real_date
					except:
						if (type_3[1].endswith(",")==True):
							real_date=type_3[1].replace(",", "")+"-"+months[type_3[0].lower()]+"-"+type_3[2]
							dates[pos]=real_date
						else:
							continue			
		
		else:
			#esto sirve para despues poder determinar el tipo de fecha si los numeros estan separados por "/"
			try:
				d_inv.append((int(type_1[1])))
				
			except:
				d_inv.append(int(type_1[1].replace("0", "")))
	
	#esta parte sirve para determinar si todas las fechas de la pagina estan puestas en formato DD/MM/YYYY o MM/DD/YYYY
	for x in d_inv:
		if (x>12):
			for days in dates:
				pos=dates.index(days)
				type_=days.split("/")
				real_date=type_[1]+"-"+type_[0]+"-"+type_[2]
				dates[pos]=real_date
				
			break
		else:
			for days in dates:
				pos=dates.index(days)
				real_date=days.replace("/", "-")
				dates[pos]=real_date
			break
	#añade un 0 delante del primer digito cuando este es una unidad
	for x in dates:
		pos=dates.index(x)
		d_inv=x.split("-")
		if (d_inv[0].startswith("0")==False and len(list(d_inv[0]))==1):
			date="0"+d_inv[0]+"-"+d_inv[1]+"-"+d_inv[2]
			dates[pos]=date
		else:
			continue
	return dates

