import os
import pyimpfuzzy
import socket
from tqdm import tqdm

def fuzzy(conn, file):
    if os.path.exists(file):
        hashes = []
        padre = "../../malware-samples"
        hijos = os.listdir(padre)

        for i in hijos:
            dir_x = padre+"/"+i
            for e in os.listdir(dir_x):
                hashes.append(dir_x+"/"+e)
        hashesLen = str(len(hashes))
        try:
            hash1 = pyimpfuzzy.get_impfuzzy(file)
        except Exception as ex:
            print("hash1: %s"%ex)
        hash2 = ""
        resultados = {}
        processInfo = "Analizando: %s"%file.split("/")[1]
        conn.send(processInfo.encode())
        conn.send(hashesLen.encode())
        for sha in hashes:
            try:
                hash2 = pyimpfuzzy.get_impfuzzy(sha)
            except Exception as ex:
                conn.send("null".encode()) # Se envia null para completar el total del for
            else:
                resultados[sha] = pyimpfuzzy.hash_compare(hash1, hash2)
                if resultados[sha] > 0:
                    info = sha.split("/")
                    info = "Ransom Group: " + info[3].upper() + " | " + "Related file: " + info[4].lower() + " "
                    processInfo = info +" "+str(resultados[sha])+"%"
                    conn.send(processInfo.encode())
                else:
                    conn.send("null".encode()) # Se envia null para completar el total del for
           

    else:
        print("El fichero no existe")

def getFile(conn, fileName, fileSize, buffer):
    with open(fileName, "wb") as f:
        while True:
            bytes_read = conn.recv(buffer)
            if not bytes_read:    
                break
            f.write(bytes_read)

def main():
    host = "0.0.0.0"
    port = 9999
    
    if not os.path.exists("./tmp"):
        os.mkdir("./tmp")

    server_socket = socket.socket()
    server_socket.bind((host, port))
    server_socket.listen(1)

    newFileSeparator = "<newFile>"
    while True:
        conn, address = server_socket.accept()
        cmd = conn.recv(1024).decode()
        conn.send("ok".encode())

        if "<newFile>" in cmd:
            fileName, fileSize = cmd.split(newFileSeparator)
            fileName = "./tmp/"+os.path.basename(fileName)
            fileSize = int(fileSize)
            buffer = 4096
            getFile(conn, fileName, fileSize, buffer)
        elif cmd == "analyzeHash":
            if len(os.listdir("tmp")) == 1:
                file = "tmp/"+os.listdir("tmp")[0]
                fuzzy(conn, file)
                os.remove(file)
            else:
                info = "ERROR <400>"
                conn.send(info.encode())

main()
