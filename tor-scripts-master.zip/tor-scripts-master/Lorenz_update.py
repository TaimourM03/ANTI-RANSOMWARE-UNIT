from datetime import datetime as dt
import requests
from time import sleep
from bs4 import BeautifulSoup as bs
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from get_paises import obtener_pais as o_p
from Conversor_fechas import date_convertor as d_c

def Lorenz():
        corps=[]
        dates=[]
        links=[]

        #url="http://localhost:1111/prueba.html"
        url="http://lorenzmlwpzgxq736jzseuterytjueszsvznuibanxomlpkyxk6ksoyd.onion/"

        session = requests.session()
        session.proxies["http"] = "socks5h://localhost:9050"
        session.proxies["https"] = "socks5h://localhost:9050"
        response = session.get(url)
        soup = bs(response.content, "html.parser")

        div_headers=soup.find_all("div", class_ ="panel-heading")

        for name in div_headers:
                if (name.h3!=None):
                        corp=name.h3.get_text()
                        if (corp.startswith(" ")==True):
                                corp2=corp.replace(" ", "", 1)
                                corps.append(corp2)
                        else:
                                corps.append(corp)
                else:
                        continue

        for elements in div_headers:
                data=elements.find_all("h5")
                for date in data:
                        day=date.get_text()
                        if(day.startswith(" Post") or day.startswith("Posted")):
                                d=day.split(" ")
                                if(d[0]==""):
                                        del d[0]
                                day=" ".join(d[1:4])
                                if (day.endswith(".")):
                                        ds=day[:-1]
                                        dates.append(ds)
                                else:
                                        dates.append(day)
                        else:
                                continue
        for no_date in corps:
                pos=corps.index(no_date)
                if (no_date=="Airtech Advanced Materials Group" or no_date=="Joy Cone"):
                        dates.insert(pos-1, "Mar 15, 2021")

        for link in div_headers:
                linkz=link.find_all("a")
                for l in linkz:
                        if (l.get_text().startswith("h")):
                                links.append(l.get_text())
        session.close()
        return [corps, links]

