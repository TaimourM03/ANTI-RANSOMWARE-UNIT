from get_paises import obtener_pais as o_p
import requests
from datetime import datetime as dt
from tqdm import tqdm
from bs4 import BeautifulSoup as bs
from Conversor_fechas import date_convertor as d_c

def Quantum():
        url = "http://quantum445bh3gzuyilxdzs5xdepf3b7lkcupswvkryf3n7hgzpxebid.onion" 
        links =[]
        empresas = []
        fechas = []
        webs =[]
        session = requests.session()
        session.proxies["http"] = "socks5h://localhost:9050"
        session.proxies["https"] = "socks5h://localhost:9050"
        
        response = session.get(url)
        session.close()
        soup = bs(response.content, "html.parser")
        data=soup.find_all("a")
        for link in data:
                l=link.get("href")
                if ((l not in links) and l!="/" and l!="/about" and l!="/contact"):
                        #print(l)
                        links.append(l)
        '''soup_empresas = soup.find_all("h2",{"class":"blog-post-title"})
        soup_fechas = soup.find_all("p",{"class":"blog-post-date pull-right"})
        for z in soup_fechas:
                fechas.append(z.text.strip())#utilizamos strip(), para quitar espacios y elementos innecesarios.
        for m in soup_empresas:
                empresas.append(m.text.strip())'''

        for link in links:
                site=url+link
                response = session.get(site)
                soup = bs(response.content, "html.parser")
                corp=soup.find_all("dd")
                #print(corp[0].get_text())
                empresas.append(corp[0].get_text())
                website=corp[1].a.get("href").replace("https://", "").replace("http://", "").replace("www.", "")
                if (website.endswith("/")):
                        #print(website[:-1])
                        webs.append(website[:-1])
                else:
                        #print(website)
                        webs.append(website)
                #print(corp[3].get_text())
                fechas.append(corp[3].get_text())
        return [empresas, webs]
