from datetime import datetime as dt
from Conversor_fechas import date_convertor as d_c
from get_paises import obtener_pais as o_p
import requests
from bs4 import BeautifulSoup as bs
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def Karakurt():
        corps=[]
        dates=[]
        webs=[]
        sectors=[]
        address=[]
        url="https://3f7nxkjway3d223j27lyad7v5cgmyaifesycvmwq7i7cbs23lb6llryd.onion/"
        session = requests.session()
        session.proxies["http"] = "socks5h://localhost:9050"
        session.proxies["https"] = "socks5h://localhost:9050"
        response = session.get(url, verify=False)
        soup = bs(response.content, "html.parser")

        prerrelease=soup.find_all("div", class_="col-md-4 col-sm-4 col-xs-12")

        for info in prerrelease:
                corps.append(info.h3.a.get_text())
                dates.append(info.span.get_text().split("2022")[0]+"2022")
                webs.append(info.find("span", class_="post-category").a.get("href").replace("https:", "").replace("http:", "").replace("/", "").replace("www.", "").replace("httsp:",""))
                sectors.append(info.find("div", class_="pull-right").span.get_text())
                address.append(info.find("span", class_="post-date ml-2").get_text())

        realising=soup.find_all("div", class_="col-xs-6 col-md-3 col-sm-3")

        for info in realising:
                corps.append(info.h3.a.get_text())
                dates.append("null")
                webs.append(info.span.a.get("href").replace("https:", "").replace("http:", "").replace("/", "").replace("www.", "").replace("httsp:",""))
                sectors.append(info.find("div", class_="pull-right").span.get_text())
                address.append(info.find("span", class_="post-date ml-2").get_text())

        released=soup.find_all("div", class_="category-mid-post-two")

        for info in released:
                corps.append(info.h2.a.get_text())
                dates.append(info.find("span", class_="post-date").get_text())
                webs.append(info.span.a.get("href").replace("https:", "").replace("http:", "").replace("/", "").replace("www.", "").replace("httsp:",""))
                sectors.append(info.find("div", class_="pull-right").find("span", class_="post-category").get_text())
                address.append(info.find("span", class_="post-date ml-2").get_text())

        #locat = o_p(webs)
        #dates = d_c(dates)
        session.close()
        excps = ["Turnberry Associates"]
        for e in excps:
            for i in range(len(corps)):
                if e in corps[i]:
                    del corps[i]
                    del webs[i]
                    break

        return [corps, webs]
