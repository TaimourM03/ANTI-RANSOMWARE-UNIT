from requests_html import HTMLSession
from get_paises import obtener_pais as o_p
from Conversor_fechas import date_convertor as d_c
import time
from bs4 import BeautifulSoup as bs
import urllib3
from tqdm import tqdm
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def Ragnar():
        non_grated=["Leak", "Leaked", "Leaks", "LEAK", "Leakage", "LEAKED", "leaks", "Leakeage", "-", "Full", "FULL", "Fully","Post", "post", "POST", "New", "NEW",'"WallofShamer"', "Update:", "Update", "update", "going", "to", "be", "(BE)", "Data", "DATA", "decided", "is", "from", "//", "Links", "for", "got", "first", "batch", "of", "(0,1%)", "at", "Law", "Security", "breach", '"Wall', 'Shamer"']
        dates=[]
        corps=[]
        links=[]

        url = "http://rgleaktxuey67yrgspmhvtnrqtgogur35lwdrup4d3igtbm3pupc4lyd.onion/"

        proxies = 'socks5h://localhost:9050'
        session = HTMLSession(browser_args=['--proxy-server = socks5h://localhost:9050'])
        r = session.get(url, proxies={'http' : proxies, 'https' : proxies})
        r.html.render(timeout=120, sleep=2)
        web=r.html.html
        soup= bs(web, "html.parser")
        '''
        ######
        url="http://localhost:1111/locker.html"
        session = requests.session()
        response = session.get(url)
        soup = bs(response.content, "html.parser")
        ######
        '''
        data=soup.find_all("div", class_ ="card")
        for info in data:
                if (("Announce" in info.a.get_text().split(" ")) or ("Announcement:" in info.a.get_text().split(" ")) or ("Who" in info.get_text().split(" "))):
                        continue
                else:
                        title=info.a.get_text().split(" ")
                        corp=[]

                        for remv in title:
                                if(remv not in non_grated):
                                        corp.append(remv)
                                else:
                                        continue

                        corps.append(" ".join(corp))
                        link=info.a.get("href")
                        date=info.find_all("small")[1]
                        day=date.get_text().split(" ")[5]
                        dates.append(day)
                        links.append(info.a.get("href")) 
        session.close()
        links = []
        for i in range(len(corps)):
            links.append("null")
        return [corps, links]
