import requests
from bs4 import BeautifulSoup as bs

def Omega():
	corps=[]
	dates=[]
	
	url="http://omegalock5zxwbhswbisc42o2q2i54vdulyvtqqbudqousisjgc7j7yd.onion/"
	#url="http://localhost:1111/a.html"
	session = requests.session()
	session.proxies["http"] = "socks5h://localhost:9050"
	session.proxies["https"] = "socks5h://localhost:9050"
	response = session.get(url)
	soup = bs(response.content, "html.parser")
	
	data=soup.find_all("tr", class_="trow")
	for information in data:
		for info in information:
			if information.index(info)==1:
				corps.append(info.get_text())
			elif information.index(info)==9:
				dates.append(info.get_text())
	webs = []
	for i in range(len(corps)):
		webs.append("null")
	return [corps, webs]
